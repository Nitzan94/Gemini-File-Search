# ABOUTME: Production-ready Gemini client singleton template
# ABOUTME: Copy this to your project's api/client.py

"""
Gemini File Search Client Singleton

This template provides a production-ready client wrapper with:
- Singleton pattern for connection reuse
- Convenience methods for common operations
- Safe attribute access for SDK responses
- Type hints for better IDE support

Usage:
    from api.client import GeminiClient

    client = GeminiClient()
    stores = client.list_stores()
"""

import os
from typing import Optional, List, Dict, Any
from google import genai
from google.genai import types


class GeminiClient:
    """Singleton wrapper for Google GenAI client with file search capabilities"""

    _instance: Optional['GeminiClient'] = None
    _client: Optional[genai.Client] = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    def __init__(self):
        if self._client is None:
            api_key = os.getenv('GEMINI_API_KEY')
            if not api_key:
                raise ValueError(
                    'GEMINI_API_KEY not found in environment. '
                    'Get your key from: https://aistudio.google.com/apikey'
                )
            self._client = genai.Client(api_key=api_key)

    @property
    def client(self) -> genai.Client:
        """Get underlying GenAI client"""
        return self._client

    # ====================
    # Store Operations
    # ====================

    def create_store(self, display_name: Optional[str] = None):
        """Create file search store"""
        config = {}
        if display_name:
            config['display_name'] = display_name
        return self._client.file_search_stores.create(config=config)

    def list_stores(self, page_size: int = 10):
        """List all file search stores"""
        return self._client.file_search_stores.list(config={'page_size': page_size})

    def get_store(self, name: str):
        """Get store by name with metrics"""
        return self._client.file_search_stores.get(name=name)

    def delete_store(self, name: str, force: bool = False):
        """Delete store (force=True for cascade delete)"""
        config = {'force': force} if force else {}
        return self._client.file_search_stores.delete(name=name, config=config)

    # ====================
    # Document Operations
    # ====================

    def upload_document(
        self,
        file_path: str,
        store_name: str,
        display_name: Optional[str] = None,
        metadata: Optional[Dict[str, str]] = None
    ):
        """Upload file to store with optional metadata"""
        config = {}
        if display_name:
            config['display_name'] = display_name
        if metadata:
            config['custom_metadata'] = [
                {'key': k, 'string_value': v}
                for k, v in metadata.items()
            ]

        return self._client.file_search_stores.upload_to_file_search_store(
            file=file_path,
            file_search_store_name=store_name,
            config=config
        )

    def list_documents(self, store_name: str, page_size: int = 10):
        """List documents in store"""
        return self._client.file_search_stores.documents.list(
            parent=store_name,
            config={'page_size': page_size}
        )

    def get_document(self, document_name: str):
        """Get document by name"""
        return self._client.file_search_stores.documents.get(name=document_name)

    def delete_document(self, document_name: str, force: bool = True):
        """Delete document (force=True if has chunks)"""
        config = {'force': force} if force else {}
        return self._client.file_search_stores.documents.delete(
            name=document_name,
            config=config
        )

    def query_document(
        self,
        document_name: str,
        query: str,
        results_count: int = 10,
        metadata_filters: Optional[List[Dict[str, str]]] = None
    ):
        """Query specific document"""
        config = {
            'query': query,
            'results_count': results_count
        }
        if metadata_filters:
            config['metadata_filters'] = metadata_filters

        return self._client.file_search_stores.documents.query(
            name=document_name,
            config=config
        )

    # ====================
    # Semantic Search
    # ====================

    def search(
        self,
        query: str,
        store_names: List[str],
        metadata_filter: Optional[str] = None,
        model: str = 'gemini-2.5-flash'
    ) -> Dict[str, Any]:
        """
        Semantic search across store(s) with citations

        Args:
            query: Search query
            store_names: List of store names (e.g., ['fileSearchStores/id'])
            metadata_filter: AIP-160 filter string (e.g., 'author=John AND year=2024')
            model: Model name (gemini-2.5-flash or gemini-2.5-pro)

        Returns:
            dict with 'text' (answer) and 'citations' (list of sources)
        """
        tool_config = types.FileSearch(
            file_search_store_names=store_names
        )
        if metadata_filter:
            tool_config.metadata_filter = metadata_filter

        response = self._client.models.generate_content(
            model=model,
            contents=query,
            config=types.GenerateContentConfig(
                tools=[types.Tool(file_search=tool_config)]
            )
        )

        # Safe citation extraction
        result = {
            'text': response.text if hasattr(response, 'text') else '',
            'citations': []
        }

        if hasattr(response, 'candidates') and response.candidates:
            candidate = response.candidates[0]
            if hasattr(candidate, 'grounding_metadata'):
                grounding = candidate.grounding_metadata
                if hasattr(grounding, 'grounding_chunks'):
                    for chunk in grounding.grounding_chunks:
                        if hasattr(chunk, 'retrieved_context'):
                            ctx = chunk.retrieved_context
                            result['citations'].append({
                                'title': getattr(ctx, 'title', ''),
                                'uri': getattr(ctx, 'uri', '')
                            })

        return result

    # ====================
    # Operation Polling
    # ====================

    def get_operation(self, operation_name: str):
        """Poll long-running operation status"""
        return self._client.operations.get(name=operation_name)
