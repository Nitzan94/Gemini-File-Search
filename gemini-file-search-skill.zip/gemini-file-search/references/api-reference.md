# Gemini File Search API Reference

Complete SDK method reference for `google-genai` file search operations.

## Client Initialization

```python
from google import genai
import os

client = genai.Client(api_key=os.getenv('GEMINI_API_KEY'))
```

## File Search Stores

### Create Store

```python
store = client.file_search_stores.create(
    config={'display_name': 'My Store'}  # Optional, max 512 chars
)
# Returns: Store object with name, display_name, create_time
```

### List Stores

```python
stores = client.file_search_stores.list(
    config={'page_size': 10}  # Default 10, max 20
)
# Returns: Iterator of Store objects
```

### Get Store

```python
store = client.file_search_stores.get(
    name='fileSearchStores/store-id'
)
# Returns: Store with metrics (active/pending/failed_documents_count, size_bytes)
```

### Delete Store

```python
client.file_search_stores.delete(
    name='fileSearchStores/store-id',
    config={'force': True}  # Required if store has documents
)
```

## Documents

### Upload Document

```python
operation = client.file_search_stores.upload_to_file_search_store(
    file='path/to/file.pdf',
    file_search_store_name='fileSearchStores/store-id',
    config={
        'display_name': 'My Document',  # Optional
        'custom_metadata': [  # Optional, max 20 key-value pairs
            {'key': 'author', 'string_value': 'John Doe'},
            {'key': 'category', 'string_value': 'reports'}
        ]
    }
)
# Returns: Long-running Operation object
```

### List Documents

```python
documents = client.file_search_stores.documents.list(
    parent='fileSearchStores/store-id',
    config={'page_size': 10}  # Default 10, max 20
)
# Returns: Iterator of Document objects
```

### Get Document

```python
document = client.file_search_stores.documents.get(
    name='fileSearchStores/store-id/documents/doc-id'
)
# Returns: Document with state, size_bytes, mime_type, custom_metadata
```

### Delete Document

```python
client.file_search_stores.documents.delete(
    name='fileSearchStores/store-id/documents/doc-id',
    config={'force': True}  # Required if document has chunks
)
```

### Query Document

```python
response = client.file_search_stores.documents.query(
    name='fileSearchStores/store-id/documents/doc-id',
    config={
        'query': 'What is the main topic?',
        'results_count': 10,  # Default 10, max 100 chunks
        'metadata_filters': [  # Optional AND/OR filtering
            {'key': 'author', 'value': 'John Doe'}
        ]
    }
)
```

## Semantic Search (generate_content)

### Basic Query

```python
from google.genai import types

response = client.models.generate_content(
    model='gemini-2.5-flash',  # or gemini-2.5-pro
    contents='What is the revenue for Q2?',
    config=types.GenerateContentConfig(
        tools=[types.Tool(
            file_search=types.FileSearch(
                file_search_store_names=['fileSearchStores/store-id']
            )
        )]
    )
)

# Access answer
answer = response.text

# Access citations (grounding metadata)
if hasattr(response, 'candidates') and response.candidates:
    candidate = response.candidates[0]
    if hasattr(candidate, 'grounding_metadata'):
        grounding = candidate.grounding_metadata
        if hasattr(grounding, 'grounding_chunks'):
            for chunk in grounding.grounding_chunks:
                if hasattr(chunk, 'retrieved_context'):
                    ctx = chunk.retrieved_context
                    title = getattr(ctx, 'title', '')
                    uri = getattr(ctx, 'uri', '')
```

### Query with Metadata Filter

```python
response = client.models.generate_content(
    model='gemini-2.5-flash',
    contents='Summarize reports from Q2',
    config=types.GenerateContentConfig(
        tools=[types.Tool(
            file_search=types.FileSearch(
                file_search_store_names=['fileSearchStores/store-id'],
                metadata_filter='category=reports AND quarter=Q2'  # AIP-160 syntax
            )
        )]
    )
)
```

## Operations (Long-Running)

### Poll Operation Status

```python
operation = client.operations.get(
    name='fileSearchStores/store-id/upload/operations/op-id'
)

# Check if complete
if operation.done:
    print('Upload complete')
```

## Document States

Documents progress through states:

- **STATE_PENDING**: Chunks being processed
- **STATE_ACTIVE**: Ready for querying
- **STATE_FAILED**: Processing failed

## Limits

**Free Tier:**
- Storage: 1 GB
- Max file size: 100 MB
- Max metadata: 20 key-value pairs per document

**Paid Tiers:**
- Tier 1: 10 GB
- Tier 2: 100 GB
- Tier 3: 1 TB

**Performance:**
- Keep stores <20 GB for best latency
- Pagination: max 20 items per page

## Supported File Formats

100+ formats including:
- Documents: PDF, DOCX, ODT, PPTX, XLSX
- Code: Python, JavaScript, Go, C++, Java
- Data: CSV, TSV, JSON, YAML, XML
- Web: HTML, Markdown
- Archives: ZIP (auto-extracted)

## Error Handling

```python
try:
    store = client.file_search_stores.create(config={})
except Exception as e:
    print(f'Error: {e}')
    # Common errors:
    # - Invalid API key
    # - Storage limit exceeded
    # - File too large (>100MB)
    # - Invalid file format
```

## Best Practices

1. **Client Singleton**: Reuse client instance across requests
2. **Operation Polling**: Poll every 2-3 seconds for upload status
3. **Metadata**: Add searchable metadata for filtering
4. **Store Size**: Keep <20 GB per store for best performance
5. **Citations**: Always extract grounding_metadata for source attribution
6. **Error Handling**: Implement retries for network errors
7. **State Tracking**: Check document state before querying

## Official Documentation

- API Docs: https://ai.google.dev/gemini-api/docs/file-search
- API Reference: https://ai.google.dev/api/file-search
- Get API Key: https://aistudio.google.com/apikey
