# Troubleshooting Guide

Common issues and solutions when working with Gemini File Search API.

## API Connection Issues

### Error: "GEMINI_API_KEY not found"

**Cause:** API key not loaded from environment

**Solution:**
```bash
# Create .env file
cp .env.example .env

# Add your key
GEMINI_API_KEY=your_actual_key_here

# Verify
python -c "import os; from dotenv import load_dotenv; load_dotenv(); print(os.getenv('GEMINI_API_KEY'))"
```

### Error: "Invalid API key"

**Cause:** Incorrect or expired API key

**Solution:**
1. Get new API key: https://aistudio.google.com/apikey
2. Update `.env` file
3. Restart application

### Error: "Module 'google.genai' not found"

**Cause:** SDK not installed

**Solution:**
```bash
uv add google-genai
# or
pip install google-genai
```

## Storage & Upload Issues

### Error: "Storage limit exceeded"

**Cause:** Free tier 1GB limit reached

**Solution:**
- Delete unused stores: `client.file_search_stores.delete(name=..., config={'force': True})`
- Check current usage: Sum `size_bytes` from `list_stores()`
- Upgrade to paid tier for more storage

### Error: "File too large"

**Cause:** File exceeds 100MB limit

**Solution:**
- Split large files into smaller chunks
- Compress files before upload
- Use PDF optimization tools for large PDFs
- Note: Limit applies per file, not total upload size

### Upload Hangs or Times Out

**Cause:** Large file upload or network issues

**Solution:**
- Increase timeout: `timeout=300` in HTTP client
- Check network connection
- Try smaller test file first
- Monitor operation status with polling

## Document State Issues

### Documents Stuck in "STATE_PENDING"

**Cause:** Background processing not complete

**Solution:**
- Wait 30-60 seconds for small files
- Large files (>10MB) may take several minutes
- Poll operation status: `client.operations.get(name=operation_name)`
- Check `done` flag before querying

### Error: "Document not found" After Upload

**Cause:** Querying before processing complete

**Solution:**
```python
# Wait for STATE_ACTIVE before querying
def wait_for_document(client, doc_name, timeout=60):
    import time
    start = time.time()

    while time.time() - start < timeout:
        doc = client.file_search_stores.documents.get(name=doc_name)
        if doc.state == 'STATE_ACTIVE':
            return doc
        time.sleep(2)

    raise TimeoutError('Document processing timeout')
```

### Documents in "STATE_FAILED"

**Cause:** Unsupported format or corrupted file

**Solution:**
- Check file format (must be in supported 100+ list)
- Verify file not corrupted
- Try re-uploading
- Check file encoding (UTF-8 recommended for text)

## Operation Polling Issues

### Error: "Operation not found" (404)

**Cause:** Incorrect operation endpoint or expired operation

**Solution:**
```python
# Correct method
operation = client.operations.get(name=operation_name)

# NOT: client.file_search_stores.get_operation()

# Full operation name includes path:
# 'fileSearchStores/store-id/upload/operations/op-id'
```

### Operation Polling Never Completes

**Cause:** Upload failed but operation not marked failed

**Solution:**
- Set max polling attempts (e.g., 30 attempts = 60 seconds)
- Check document state directly
- Cancel and retry upload
- Verify file format supported

## Query & Search Issues

### Empty Results from Semantic Search

**Cause:** Documents not active, query too specific, or no relevant content

**Solution:**
1. Verify documents are STATE_ACTIVE
2. Try broader query
3. Check metadata filters not too restrictive
4. Verify store has documents: `list_documents()`
5. Test with simple query: "What is this document about?"

### No Citations in Response

**Cause:** Grounding metadata not extracted correctly

**Solution:**
```python
# Safe citation extraction
result = {'text': response.text, 'citations': []}

if hasattr(response, 'candidates') and response.candidates:
    candidate = response.candidates[0]
    if hasattr(candidate, 'grounding_metadata'):
        grounding = candidate.grounding_metadata
        if hasattr(grounding, 'grounding_chunks'):
            for chunk in grounding.grounding_chunks:
                if hasattr(chunk, 'retrieved_context'):
                    ctx = chunk.retrieved_context
                    result['citations'].append({
                        'title': getattr(ctx, 'title', ''),
                        'uri': getattr(ctx, 'uri', '')
                    })
```

### Metadata Filters Not Working

**Cause:** Incorrect AIP-160 syntax

**Solution:**
```python
# Correct syntax
metadata_filter='author=John AND category=reports'
metadata_filter='year=2024 OR year=2025'
metadata_filter='status!=draft'

# Incorrect
metadata_filter={'author': 'John'}  # Wrong - must be string
metadata_filter='author==John'  # Wrong - use single =
```

## SDK Method Issues

### Error: "'FileSearchStores' object has no attribute 'list_documents'"

**Cause:** Wrong SDK method path

**Solution:**
```python
# Correct: documents is a sub-resource
documents = client.file_search_stores.documents.list(
    parent='fileSearchStores/store-id'
)

# NOT: client.file_search_stores.list_documents()
```

### Error: "'FileSearchStores' object has no attribute 'get_document'"

**Cause:** Wrong SDK method path

**Solution:**
```python
# Correct
doc = client.file_search_stores.documents.get(
    name='fileSearchStores/store-id/documents/doc-id'
)

# NOT: client.file_search_stores.get_document()
```

## FastAPI Integration Issues

### Static Files Return 404

**Cause:** Relative paths don't work with uvicorn

**Solution:**
```python
from pathlib import Path

BASE_DIR = Path(__file__).parent
app.mount('/static', StaticFiles(directory=str(BASE_DIR / 'static')))
```

### Route Conflicts (API vs Pages)

**Cause:** Both API and page routes use same path

**Solution:**
```python
# Prefix API routes
router = APIRouter(prefix='/api/stores')

# Page routes separate
@app.get('/stores/{store_id}')  # HTML page
async def page(...): ...
```

### Multipart Upload Fails

**Cause:** Missing `python-multipart` dependency

**Solution:**
```bash
uv add python-multipart
```

## Performance Issues

### Slow Query Response

**Cause:** Large store (>20GB) or many documents

**Solution:**
- Keep stores <20 GB for best latency
- Use metadata filters to narrow search
- Split into multiple smaller stores
- Consider upgrading to Pro model for faster response

### High Memory Usage

**Cause:** Loading large files into memory

**Solution:**
```python
# Stream file uploads
with tempfile.NamedTemporaryFile(delete=False) as tmp:
    # Write in chunks
    while chunk := await file.read(8192):
        tmp.write(chunk)
```

## Testing Issues

### Tests Skip with "GEMINI_API_KEY not set"

**Cause:** .env not loaded in test environment

**Solution:**
```python
# In test file
from dotenv import load_dotenv
load_dotenv()  # Load before importing app

@pytest.fixture
def client():
    if not os.getenv('GEMINI_API_KEY'):
        pytest.skip('GEMINI_API_KEY not set')
    from main import app
    return TestClient(app)
```

### Tests Fail with Quota Exceeded

**Cause:** Too many test store creations

**Solution:**
- Use fixture with cleanup
- Delete test stores after each test
- Use `force=True` when deleting
- Check quota usage in console

## Common Patterns to Avoid

❌ **Don't:** Query documents immediately after upload
✅ **Do:** Wait for STATE_ACTIVE

❌ **Don't:** Use hardcoded paths for templates
✅ **Do:** Use BASE_DIR pattern

❌ **Don't:** Forget to clean up temp files
✅ **Do:** Use context managers or explicit cleanup

❌ **Don't:** Assume citations always present
✅ **Do:** Use safe extraction with `hasattr`

❌ **Don't:** Poll operations forever
✅ **Do:** Set max attempts timeout

❌ **Don't:** Store API key in code
✅ **Do:** Use environment variables

## Getting Help

1. Check official docs: https://ai.google.dev/gemini-api/docs/file-search
2. Verify SDK version: `pip show google-genai`
3. Test connection: `python scripts/test_connection.py`
4. Check API status: Google Cloud Status Dashboard
5. Review API quotas: Google AI Studio console

## Debug Checklist

When troubleshooting, check in order:

1. ✓ API key valid and loaded
2. ✓ SDK installed and correct version
3. ✓ Documents in STATE_ACTIVE (not pending)
4. ✓ Store ID format correct (`fileSearchStores/...`)
5. ✓ File size under 100MB
6. ✓ File format supported
7. ✓ Storage under tier limit
8. ✓ Network connection stable
9. ✓ Correct SDK method paths
10. ✓ Citations extracted safely
