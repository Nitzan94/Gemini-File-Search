# FastAPI Integration Patterns

Proven patterns for integrating Gemini File Search with FastAPI web applications.

## Project Structure

```
project/
├── main.py                 # FastAPI app entry point
├── api/
│   ├── __init__.py
│   ├── client.py          # GenAI client singleton
│   ├── stores.py          # Store CRUD routes
│   ├── documents.py       # Document upload/manage routes
│   └── query.py           # Semantic search routes
├── templates/             # Jinja2 templates
│   ├── base.html
│   ├── dashboard.html     # Store list
│   └── store_detail.html  # Upload & search UI
├── static/
│   └── app.js
└── tests/
    └── test_api.py
```

## Client Singleton Pattern

**File: `api/client.py`**

```python
import os
from typing import Optional
from google import genai

class GeminiClient:
    """Singleton wrapper for Google GenAI client"""

    _instance: Optional['GeminiClient'] = None
    _client: Optional[genai.Client] = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    def __init__(self):
        if self._client is None:
            api_key = os.getenv('GEMINI_API_KEY')
            if not api_key:
                raise ValueError('GEMINI_API_KEY not found')
            self._client = genai.Client(api_key=api_key)

    @property
    def client(self) -> genai.Client:
        return self._client

    # Convenience methods
    def create_store(self, display_name: Optional[str] = None):
        config = {}
        if display_name:
            config['display_name'] = display_name
        return self._client.file_search_stores.create(config=config)

    def list_stores(self, page_size: int = 10):
        return self._client.file_search_stores.list(
            config={'page_size': page_size}
        )

    # ... more convenience methods
```

**Why Singleton:**
- Reuses API connection across requests
- Prevents redundant client initialization
- Thread-safe instance management

## Store CRUD Router

**File: `api/stores.py`**

```python
from typing import Optional
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from .client import GeminiClient

router = APIRouter(prefix='/api/stores', tags=['stores'])

class CreateStoreRequest(BaseModel):
    display_name: Optional[str] = None

@router.post('')
async def create_store(request: CreateStoreRequest):
    try:
        client = GeminiClient()
        store = client.create_store(display_name=request.display_name)
        return {
            'name': store.name,
            'display_name': store.display_name,
            'create_time': store.create_time
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.get('')
async def list_stores(page_size: int = 10):
    try:
        client = GeminiClient()
        stores = client.list_stores(page_size=page_size)
        return {
            'stores': [
                {
                    'name': s.name,
                    'display_name': s.display_name,
                    'active_documents_count': getattr(s, 'active_documents_count', 0),
                    'size_bytes': getattr(s, 'size_bytes', 0)
                }
                for s in stores
            ]
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
```

## Async File Upload Pattern

**File: `api/documents.py`**

```python
import os
import tempfile
from typing import Optional
from fastapi import APIRouter, UploadFile, File, Form, HTTPException
from .client import GeminiClient

router = APIRouter(prefix='/api/stores', tags=['documents'])

@router.post('/{store_id}/upload')
async def upload_document(
    store_id: str,
    file: UploadFile = File(...),
    display_name: Optional[str] = Form(None),
    metadata: Optional[str] = Form(None)
):
    try:
        # Save to temp file
        with tempfile.NamedTemporaryFile(
            delete=False,
            suffix=os.path.splitext(file.filename)[1]
        ) as tmp:
            content = await file.read()
            tmp.write(content)
            tmp_path = tmp.name

        # Parse metadata (JSON string)
        metadata_dict = None
        if metadata:
            import json
            metadata_dict = json.loads(metadata)

        # Upload to Gemini
        client = GeminiClient()
        operation = client.upload_document(
            file_path=tmp_path,
            store_name=f'fileSearchStores/{store_id}',
            display_name=display_name or file.filename,
            metadata=metadata_dict
        )

        # Clean up
        os.unlink(tmp_path)

        return {
            'operation_name': operation.name,
            'done': operation.done,
            'message': 'Upload initiated'
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
```

**Key Points:**
1. Use `tempfile.NamedTemporaryFile` for uploaded files
2. Preserve file extension with `suffix`
3. Clean up temp file after upload
4. Return operation name for status polling
5. Handle multipart form data (file + metadata)

## Operation Polling Endpoint

```python
@router.get('/operations/{operation_id}')
async def get_operation_status(operation_id: str):
    try:
        client = GeminiClient()
        operation = client.get_operation(operation_name=operation_id)
        return {
            'name': operation.name,
            'done': operation.done
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
```

## Semantic Search with Citations

**File: `api/query.py`**

```python
from typing import Optional
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from .client import GeminiClient

router = APIRouter(prefix='/api/query', tags=['query'])

class QueryRequest(BaseModel):
    query: str
    store_ids: list[str]
    metadata_filter: Optional[str] = None
    model: str = 'gemini-2.5-flash'

@router.post('')
async def search(request: QueryRequest):
    try:
        client = GeminiClient()

        # Build store names
        store_names = [
            f'fileSearchStores/{store_id}'
            for store_id in request.store_ids
        ]

        # Perform search
        response = client.search(
            query=request.query,
            store_names=store_names,
            metadata_filter=request.metadata_filter,
            model=request.model
        )

        # Extract citations
        result = {
            'text': response.text if hasattr(response, 'text') else '',
            'citations': []
        }

        if hasattr(response, 'candidates') and response.candidates:
            candidate = response.candidates[0]
            if hasattr(candidate, 'grounding_metadata'):
                grounding = candidate.grounding_metadata
                if hasattr(grounding, 'grounding_chunks'):
                    for chunk in grounding.grounding_chunks:
                        if hasattr(chunk, 'retrieved_context'):
                            ctx = chunk.retrieved_context
                            result['citations'].append({
                                'title': getattr(ctx, 'title', ''),
                                'uri': getattr(ctx, 'uri', '')
                            })

        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
```

## Main App Setup

**File: `main.py`**

```python
import os
from pathlib import Path
from dotenv import load_dotenv
from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

from api.stores import router as stores_router
from api.documents import router as documents_router
from api.query import router as query_router

load_dotenv()

if not os.getenv('GEMINI_API_KEY'):
    raise ValueError('GEMINI_API_KEY not found')

app = FastAPI(title='Gemini File Search')

# Setup paths
BASE_DIR = Path(__file__).parent
templates = Jinja2Templates(directory=str(BASE_DIR / 'templates'))
app.mount('/static', StaticFiles(directory=str(BASE_DIR / 'static')), name='static')

# Include routers
app.include_router(stores_router)
app.include_router(documents_router)
app.include_router(query_router)

@app.get('/', response_class=HTMLResponse)
async def dashboard(request: Request):
    return templates.TemplateResponse(request, 'dashboard.html')

@app.get('/stores/{store_id}', response_class=HTMLResponse)
async def store_detail(request: Request, store_id: str):
    return templates.TemplateResponse(
        request,
        'store_detail.html',
        {'store_id': store_id}
    )

if __name__ == '__main__':
    import uvicorn
    uvicorn.run('main:app', host='0.0.0.0', port=8000, reload=True)
```

**Key Points:**
1. Use absolute paths for templates/static (BASE_DIR pattern)
2. Prefix API routes with `/api` to avoid conflicts with page routes
3. Load .env before app initialization
4. Validate API key at startup

## Frontend Integration (HTMX)

**Upload with Progress:**

```html
<div class="drop-zone" id="drop-zone">
    Drag & drop files here
    <input type="file" id="file-input" multiple style="display: none;">
</div>
<div id="upload-progress"></div>

<script>
async function handleFiles(files) {
    for (const file of files) {
        const formData = new FormData();
        formData.append('file', file);
        formData.append('display_name', file.name);

        const response = await fetch(`/api/stores/${storeId}/upload`, {
            method: 'POST',
            body: formData
        });

        if (response.ok) {
            const result = await response.json();
            // Poll operation
            if (result.operation_name) {
                pollOperation(result.operation_name);
            }
        }
    }
}

async function pollOperation(operationName) {
    const interval = setInterval(async () => {
        const response = await fetch(
            `/api/stores/operations/${encodeURIComponent(operationName)}`
        );
        const operation = await response.json();

        if (operation.done) {
            clearInterval(interval);
            // Refresh document list
        }
    }, 2000);
}
</script>
```

## Testing Pattern

**File: `tests/test_api.py`**

```python
import os
import pytest
from dotenv import load_dotenv
from fastapi.testclient import TestClient

load_dotenv()

@pytest.fixture
def client():
    if not os.getenv('GEMINI_API_KEY'):
        pytest.skip('GEMINI_API_KEY not set')

    from main import app
    return TestClient(app)

@pytest.fixture
def test_store(client):
    """Create test store and clean up after"""
    response = client.post('/api/stores', json={'display_name': 'Test'})
    assert response.status_code == 200
    store_id = response.json()['name'].split('/')[1]

    yield store_id

    client.delete(f'/api/stores/{store_id}?force=true')

def test_upload_document(client, test_store, tmp_path):
    test_file = tmp_path / 'test.txt'
    test_file.write_text('Test content')

    with open(test_file, 'rb') as f:
        response = client.post(
            f'/api/stores/{test_store}/upload',
            files={'file': ('test.txt', f, 'text/plain')},
            data={'display_name': 'Test Document'}
        )

    assert response.status_code == 200
    assert 'operation_name' in response.json()
```

## Environment Setup

**.env:**
```
GEMINI_API_KEY=your_api_key_here
```

**pyproject.toml (uv):**
```toml
[project]
dependencies = [
    "fastapi",
    "uvicorn",
    "google-genai",
    "python-multipart",
    "python-dotenv",
    "jinja2"
]

[tool.uv]
dev-dependencies = [
    "pytest",
    "pytest-asyncio",
    "httpx"
]
```

**Install:**
```bash
uv sync
```

## Run

```bash
# Development
uv run python main.py

# Production
uv run uvicorn main:app --host 0.0.0.0 --port 8000
```

## Common Patterns Summary

1. **Singleton Client**: One instance across all requests
2. **Temp Files**: For multipart uploads, clean up after
3. **Operation Polling**: 2-second intervals on frontend
4. **Citations Extraction**: Parse grounding_metadata safely with `hasattr`
5. **Error Handling**: Try/except with HTTPException
6. **API Prefix**: `/api/*` to separate from page routes
7. **Absolute Paths**: Use `BASE_DIR` pattern for templates/static
8. **State Tracking**: Check document states before operations
