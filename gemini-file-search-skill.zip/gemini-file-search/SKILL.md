---
name: gemini-file-search
description: This skill should be used when building RAG systems with Google's Gemini File Search API. Triggers include requests like "build semantic search", "create RAG with Gemini", "integrate file search API", "upload documents for search", or working with document Q&A systems. Provides setup guidance, proven FastAPI integration patterns, SDK methods, citation extraction, and troubleshooting for managed RAG implementation.
---

# Gemini File Search

Build production-ready RAG (Retrieval-Augmented Generation) applications using Google's Gemini File Search API. This skill provides proven patterns for semantic document search with citations, FastAPI integration, and comprehensive error handling.

## Overview

Gemini File Search is Google's managed RAG solution that handles document chunking, embedding, and semantic search. Use this skill when building applications that need to:

- Query documents with natural language (semantic search)
- Extract answers with source citations
- Handle 100+ file formats (PDF, DOCX, code, etc.)
- Scale from 1GB (free) to 1TB storage
- Integrate with FastAPI web applications

**vs Traditional Vector RAG:** No manual chunking/embedding - Gemini handles it
**vs PageIndex:** Simpler API, managed infrastructure, faster development

## Table of Contents

- [Quick Start](#quick-start)
- [Core Workflow](#core-workflow)
  - [Step 1: Setup](#step-1-setup)
  - [Step 2: Create Store](#step-2-create-store)
  - [Step 3: Upload Documents](#step-3-upload-documents)
  - [Step 4: Query Documents](#step-4-query-documents)
- [FastAPI Integration](#fastapi-integration)
- [Advanced Features](#advanced-features)
- [Resources](#resources)

## Quick Start

**Install dependencies:**
```bash
uv add fastapi uvicorn google-genai python-multipart python-dotenv jinja2
```

**Get API key:** https://aistudio.google.com/apikey

**Test connection:**
```bash
export GEMINI_API_KEY=your_key_here
python scripts/test_connection.py
```

**Initialize client:** Use `scripts/init_gemini_client.py` or copy `assets/client_template.py` to your project.

## Core Workflow

### Step 1: Setup

Create client singleton for connection reuse:

```python
# api/client.py
import os
from google import genai

class GeminiClient:
    _instance = None
    _client = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    def __init__(self):
        if self._client is None:
            api_key = os.getenv('GEMINI_API_KEY')
            if not api_key:
                raise ValueError('GEMINI_API_KEY not found')
            self._client = genai.Client(api_key=api_key)

    @property
    def client(self):
        return self._client
```

**Why singleton:** Reuses API connection across requests, prevents redundant initialization.

For complete client with convenience methods, copy `assets/client_template.py`.

### Step 2: Create Store

Stores are containers for documents. Create one per project or use case:

```python
from api.client import GeminiClient

client = GeminiClient()

# Create store
store = client.create_store(display_name='My Documents')
print(f'Store: {store.name}')
# Output: fileSearchStores/store-d0ttyrh6580l

# List stores
stores = client.list_stores()
for s in stores:
    print(f'{s.display_name}: {s.active_documents_count} docs, {s.size_bytes} bytes')

# Get store metrics
store = client.get_store(name='fileSearchStores/store-id')
print(f'Active: {store.active_documents_count}')
print(f'Pending: {store.pending_documents_count}')
print(f'Failed: {store.failed_documents_count}')
```

**Store lifecycle:** Create → upload docs → query → delete when done

### Step 3: Upload Documents

Upload files and track processing state:

```python
# Upload file
operation = client.upload_document(
    file_path='document.pdf',
    store_name='fileSearchStores/store-id',
    display_name='Q2 Report',
    metadata={'author': 'John', 'quarter': 'Q2'}  # Optional, max 20 pairs
)

# Poll operation until complete
import time
while not operation.done:
    operation = client.get_operation(operation_name=operation.name)
    time.sleep(2)

# Check document state
doc = client.list_documents(store_name='fileSearchStores/store-id')
for d in doc:
    print(f'{d.display_name}: {d.state}')
    # STATE_PENDING → STATE_ACTIVE → ready to query
    # STATE_FAILED → processing error, check format
```

**Important:** Only query documents in STATE_ACTIVE. Wait for processing to complete.

**Supported formats:** PDF, DOCX, PPTX, XLSX, Python, JavaScript, Go, C++, CSV, JSON, HTML, Markdown, ZIP (100+ total)

**Limits:** 100MB per file, 1GB total (free tier)

### Step 4: Query Documents

Semantic search with citation extraction:

```python
from google.genai import types

# Basic query
response = client.models.generate_content(
    model='gemini-2.5-flash',
    contents='What was the Q2 revenue?',
    config=types.GenerateContentConfig(
        tools=[types.Tool(
            file_search=types.FileSearch(
                file_search_store_names=['fileSearchStores/store-id']
            )
        )]
    )
)

print(response.text)
# Output: "The Q2 revenue was $50M according to the financial report."

# Extract citations safely
citations = []
if hasattr(response, 'candidates') and response.candidates:
    candidate = response.candidates[0]
    if hasattr(candidate, 'grounding_metadata'):
        grounding = candidate.grounding_metadata
        if hasattr(grounding, 'grounding_chunks'):
            for chunk in grounding.grounding_chunks:
                if hasattr(chunk, 'retrieved_context'):
                    ctx = chunk.retrieved_context
                    citations.append({
                        'title': getattr(ctx, 'title', ''),
                        'uri': getattr(ctx, 'uri', '')
                    })

# Query with metadata filter
response = client.models.generate_content(
    model='gemini-2.5-flash',
    contents='Summarize Q2 reports',
    config=types.GenerateContentConfig(
        tools=[types.Tool(
            file_search=types.FileSearch(
                file_search_store_names=['fileSearchStores/store-id'],
                metadata_filter='quarter=Q2 AND author=John'  # AIP-160 syntax
            )
        )]
    )
)
```

**Metadata filter syntax:**
- AND: `key1=value1 AND key2=value2`
- OR: `key1=value1 OR key2=value2`
- NOT: `key!=value`

**Always:** Use `hasattr` when extracting citations - not all responses have grounding metadata.

## FastAPI Integration

Integrate into web applications with proven patterns:

### Project Structure

```
project/
├── main.py                 # FastAPI app
├── api/
│   ├── client.py          # Singleton client
│   ├── stores.py          # Store CRUD
│   ├── documents.py       # Upload/manage
│   └── query.py           # Search
├── templates/
│   ├── dashboard.html     # UI
│   └── store_detail.html
└── tests/
    └── test_api.py
```

### Upload Endpoint Pattern

Handle multipart file uploads with temp files:

```python
# api/documents.py
import os
import tempfile
from fastapi import APIRouter, UploadFile, File, Form, HTTPException
from .client import GeminiClient

router = APIRouter(prefix='/api/stores', tags=['documents'])

@router.post('/{store_id}/upload')
async def upload_document(
    store_id: str,
    file: UploadFile = File(...),
    display_name: Optional[str] = Form(None),
    metadata: Optional[str] = Form(None)  # JSON string
):
    try:
        # Save to temp file
        with tempfile.NamedTemporaryFile(
            delete=False,
            suffix=os.path.splitext(file.filename)[1]
        ) as tmp:
            content = await file.read()
            tmp.write(content)
            tmp_path = tmp.name

        # Parse metadata
        metadata_dict = None
        if metadata:
            import json
            metadata_dict = json.loads(metadata)

        # Upload
        client = GeminiClient()
        operation = client.upload_document(
            file_path=tmp_path,
            store_name=f'fileSearchStores/{store_id}',
            display_name=display_name or file.filename,
            metadata=metadata_dict
        )

        # Clean up temp file
        os.unlink(tmp_path)

        return {
            'operation_name': operation.name,
            'done': operation.done,
            'message': 'Upload initiated'
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
```

**Key pattern:** tempfile → upload → cleanup

### Query Endpoint Pattern

Return structured results with citations:

```python
# api/query.py
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from .client import GeminiClient

router = APIRouter(prefix='/api/query', tags=['query'])

class QueryRequest(BaseModel):
    query: str
    store_ids: list[str]
    metadata_filter: Optional[str] = None
    model: str = 'gemini-2.5-flash'

@router.post('')
async def search(request: QueryRequest):
    try:
        client = GeminiClient()

        # Build store names
        store_names = [f'fileSearchStores/{sid}' for sid in request.store_ids]

        # Use client's search method with safe citation extraction
        result = client.search(
            query=request.query,
            store_names=store_names,
            metadata_filter=request.metadata_filter,
            model=request.model
        )

        return result  # {'text': '...', 'citations': [...]}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
```

### Main App Setup

```python
# main.py
from pathlib import Path
from dotenv import load_dotenv
from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles

from api.stores import router as stores_router
from api.documents import router as documents_router
from api.query import router as query_router

load_dotenv()

app = FastAPI(title='Gemini File Search')

# Use absolute paths
BASE_DIR = Path(__file__).parent
app.mount('/static', StaticFiles(directory=str(BASE_DIR / 'static')))

# Include routers
app.include_router(stores_router)
app.include_router(documents_router)
app.include_router(query_router)
```

**Important:** Use BASE_DIR pattern for static files - relative paths fail with uvicorn.

**Complete patterns:** See `references/fastapi-patterns.md` for full integration examples including HTMX frontend, testing, and environment setup.

## Advanced Features

### Metadata Filtering

Add searchable metadata for filtering:

```python
# Upload with metadata
operation = client.upload_document(
    file_path='report.pdf',
    store_name='fileSearchStores/store-id',
    metadata={
        'author': 'John Doe',
        'department': 'Finance',
        'year': '2024',
        'category': 'quarterly-report'
    }
)

# Query with filters
response = client.search(
    query='What was the revenue?',
    store_names=['fileSearchStores/store-id'],
    metadata_filter='department=Finance AND year=2024'
)
```

**Limit:** 20 key-value pairs per document

### Document State Tracking

Monitor processing progress:

```python
def wait_for_active(client, doc_name, timeout=60):
    """Wait for document to become active"""
    import time
    start = time.time()

    while time.time() - start < timeout:
        doc = client.get_document(document_name=doc_name)
        if doc.state == 'STATE_ACTIVE':
            return True
        elif doc.state == 'STATE_FAILED':
            raise ValueError(f'Document processing failed: {doc_name}')
        time.sleep(2)

    raise TimeoutError('Document processing timeout')

# Use before querying
wait_for_active(client, 'fileSearchStores/store-id/documents/doc-id')
```

### Operation Polling Pattern

Frontend JavaScript for upload progress:

```javascript
async function pollOperation(operationName) {
    const interval = setInterval(async () => {
        const response = await fetch(
            `/api/stores/operations/${encodeURIComponent(operationName)}`
        );
        const operation = await response.json();

        if (operation.done) {
            clearInterval(interval);
            console.log('Upload complete');
            // Refresh document list
        }
    }, 2000);  // Poll every 2 seconds
}
```

### Multiple Store Queries

Search across multiple stores simultaneously:

```python
response = client.search(
    query='Find all mentions of revenue',
    store_names=[
        'fileSearchStores/financial-docs',
        'fileSearchStores/quarterly-reports',
        'fileSearchStores/annual-reports'
    ]
)
```

## Resources

This skill includes comprehensive reference documentation:

### scripts/
- `init_gemini_client.py` - Client singleton boilerplate
- `test_connection.py` - Validate API connection

Run tests: `python scripts/test_connection.py`

### references/
- `api-reference.md` - Complete SDK method documentation with examples
- `fastapi-patterns.md` - Production FastAPI integration patterns
- `troubleshooting.md` - Common issues and solutions

Load references when needed for deep technical details.

### assets/
- `client_template.py` - Production-ready client singleton

Copy to your project: `cp assets/client_template.py api/client.py`

## Common Patterns

**Do's:**
- ✓ Use singleton pattern for client
- ✓ Wait for STATE_ACTIVE before querying
- ✓ Extract citations safely with `hasattr`
- ✓ Use tempfile for uploads with cleanup
- ✓ Poll operations with 2-second intervals
- ✓ Use absolute paths for static files (BASE_DIR)
- ✓ Add metadata for filtering capabilities
- ✓ Implement max polling attempts (timeout)

**Don'ts:**
- ✗ Query documents immediately after upload
- ✗ Assume citations always present
- ✗ Use relative paths for static files
- ✗ Forget to clean up temp files
- ✗ Poll operations forever
- ✗ Store API key in code

## Troubleshooting

**Common issues:**

1. **"Operation not found" (404):** Use `client.operations.get()` not `file_search_stores.get_operation()`
2. **Documents stuck pending:** Wait 30-60s for processing, check with `get_document()`
3. **Empty search results:** Verify documents STATE_ACTIVE, try broader query
4. **Static files 404:** Use BASE_DIR pattern for absolute paths
5. **SDK method errors:** Use `documents.list()` not `list_documents()`

See `references/troubleshooting.md` for comprehensive debugging guide.

## External Resources

- Official Docs: https://ai.google.dev/gemini-api/docs/file-search
- API Reference: https://ai.google.dev/api/file-search
- Get API Key: https://aistudio.google.com/apikey
- SDK GitHub: https://github.com/googleapis/python-genai

## Next Steps

1. Test connection: `python scripts/test_connection.py`
2. Copy client template: `cp assets/client_template.py api/client.py`
3. Follow core workflow for basic implementation
4. Reference `fastapi-patterns.md` for web integration
5. Check `troubleshooting.md` when issues arise

Build semantic search applications with confidence using these proven patterns.
