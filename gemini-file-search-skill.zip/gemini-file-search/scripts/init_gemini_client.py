# ABOUTME: Boilerplate for initializing Gemini client singleton
# ABOUTME: Handles API key loading and client setup

"""
Initialize Gemini File Search client with singleton pattern.

Usage:
    from api.client import GeminiClient

    client = GeminiClient()
    stores = client.list_stores()
"""

import os
from typing import Optional
from google import genai


class GeminiClient:
    """Singleton wrapper for Google GenAI client with file search capabilities"""

    _instance: Optional['GeminiClient'] = None
    _client: Optional[genai.Client] = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    def __init__(self):
        if self._client is None:
            api_key = os.getenv('GEMINI_API_KEY')
            if not api_key:
                raise ValueError('GEMINI_API_KEY not found in environment')
            self._client = genai.Client(api_key=api_key)

    @property
    def client(self) -> genai.Client:
        """Get underlying GenAI client"""
        return self._client


# Quick test
if __name__ == '__main__':
    from dotenv import load_dotenv
    load_dotenv()

    try:
        client = GeminiClient()
        print('[OK] Client initialized successfully')
        print(f'[OK] Client instance: {client.client}')
    except Exception as e:
        print(f'[ERROR] Failed to initialize: {e}')
