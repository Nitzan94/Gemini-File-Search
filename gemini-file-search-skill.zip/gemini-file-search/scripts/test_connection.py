# ABOUTME: Quick test script to validate Gemini API connection
# ABOUTME: Checks API key and creates/deletes test store

"""
Test Gemini File Search API connection.

Usage:
    python test_connection.py

Requires: GEMINI_API_KEY in environment
"""

import os
import sys
from dotenv import load_dotenv

load_dotenv()

try:
    from google import genai
except ImportError:
    print('[ERROR] google-genai not installed. Run: uv add google-genai')
    sys.exit(1)

def test_connection():
    """Test API connection by creating and deleting a test store"""

    api_key = os.getenv('GEMINI_API_KEY')
    if not api_key:
        print('[ERROR] GEMINI_API_KEY not found in environment')
        print('[INFO] Get your API key from: https://aistudio.google.com/apikey')
        return False

    try:
        print('[INFO] Initializing client...')
        client = genai.Client(api_key=api_key)

        print('[INFO] Creating test store...')
        store = client.file_search_stores.create(
            config={'display_name': 'Connection Test'}
        )
        print(f'[OK] Store created: {store.name}')

        print('[INFO] Deleting test store...')
        client.file_search_stores.delete(name=store.name, config={'force': True})
        print('[OK] Store deleted')

        print('[OK] Connection test successful!')
        return True

    except Exception as e:
        print(f'[ERROR] Connection failed: {e}')
        return False

if __name__ == '__main__':
    success = test_connection()
    sys.exit(0 if success else 1)
